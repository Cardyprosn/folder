-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : ven. 16 déc. 2022 à 01:46
-- Version du serveur :  10.5.16-MariaDB
-- Version de PHP : 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `id19666067_utilisateurs`
--

-- --------------------------------------------------------

--
-- Structure de la table `Utilisateurs`
--

CREATE TABLE `Utilisateurs` (
  `ID` int(11) NOT NULL,
  `Username` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `First_name` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Last_name` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Mail` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Date_inscription` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `Derniere_connexion` datetime(6) DEFAULT NULL,
  `Valid` int(1) NOT NULL DEFAULT 1,
  `Ban` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `Verification`
--

CREATE TABLE `Verification` (
  `ID` int(11) NOT NULL,
  `Username` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `First_name` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Last_name` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Mail` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Cle_de_verification` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Date_verification` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `Date_enregistrement` date NOT NULL DEFAULT current_timestamp(),
  `Heure_enregistrement` time(6) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `Verification`
--

INSERT INTO `Verification` (`ID`, `Username`, `First_name`, `Last_name`, `Mail`, `Password`, `Cle_de_verification`, `Date_verification`, `Date_enregistrement`, `Heure_enregistrement`) VALUES
(42, 'ousmane', NULL, NULL, 'ousmandoye1234@gmail.com', 'Ousmane.2004', '225050', '2022-12-15 14:22:03.051373', '2022-12-15', '14:22:03.000000');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Utilisateurs`
--
ALTER TABLE `Utilisateurs`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Verification`
--
ALTER TABLE `Verification`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Utilisateurs`
--
ALTER TABLE `Utilisateurs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `Verification`
--
ALTER TABLE `Verification`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
